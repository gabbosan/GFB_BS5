/* ============================================
   GFB — Portfólio
   JS moderno (ES6+): IntersectionObserver,
   smooth scroll com rAF e menu acessível
   ============================================ */
(() => {
  'use strict';

  /* Marca que JS está disponível (controla animações no CSS) */
  document.documentElement.classList.add('js');

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ============================================
     1. SMOOTH SCROLL + FECHAR MENU MOBILE
     ============================================ */
  const NAVBAR_HEIGHT = 50;
  const SCROLL_DURATION = 700;

  const easeInOutQuad = (t) => (t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t);

  const smoothScrollTo = (targetY, hash) => {
    if (prefersReducedMotion) {
      window.scrollTo(0, targetY);
      updateHash(hash);
      return;
    }

    const startY = window.scrollY;
    const distance = targetY - startY;
    let startTime = null;

    const step = (timestamp) => {
      if (startTime === null) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const progress = Math.min(elapsed / SCROLL_DURATION, 1);
      window.scrollTo(0, Math.round(startY + distance * easeInOutQuad(progress)));

      if (elapsed < SCROLL_DURATION) {
        requestAnimationFrame(step);
      } else {
        updateHash(hash);
      }
    };

    requestAnimationFrame(step);
  };

  const updateHash = (hash) => {
    try {
      history.replaceState(null, '', hash);
      window.getSelection()?.removeAllRanges();
    } catch { /* ambiente sem history API */ }
  };

  const closeMobileMenu = () => {
    const navMenu = document.getElementById('navMenu');
    if (!navMenu?.classList.contains('show')) return;
    bootstrap.Collapse.getInstance(navMenu)?.hide();
  };

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (event) => {
      const hash = anchor.getAttribute('href');
      if (!hash || hash === '#') return;

      const target = document.querySelector(hash);
      if (!target) return;

      event.preventDefault();
      closeMobileMenu();

      const targetY = Math.max(
        target.getBoundingClientRect().top + window.scrollY - NAVBAR_HEIGHT,
        0
      );
      smoothScrollTo(targetY, hash);
    });
  });

  /* Fecha o menu ao clicar fora dele (mobile) */
  document.addEventListener('click', (event) => {
    const navMenu = document.getElementById('navMenu');
    const navbar = document.querySelector('.navbar');

    if (navMenu?.classList.contains('show') && !navbar.contains(event.target)) {
      bootstrap.Collapse.getInstance(navMenu)?.hide();
    }
  });

  /* ============================================
     2. ANIMAÇÃO DE ENTRADA — IntersectionObserver
     ============================================ */
  const revealElements = document.querySelectorAll('.reveal');

  if (prefersReducedMotion || !('IntersectionObserver' in window)) {
    revealElements.forEach((el) => el.classList.add('is-visible'));
  } else {
    const revealObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target); // anima uma única vez
          }
        });
      },
      { rootMargin: '0px 0px -12% 0px', threshold: 0 }
    );

    revealElements.forEach((el) => revealObserver.observe(el));
  }

  /* ============================================
     3. HIGHLIGHT DO MENU CONFORME SEÇÃO VISÍVEL
     ============================================ */
  const navLinks = [...document.querySelectorAll('.nav-link')];
  const sections = [...document.querySelectorAll('section[id]')];

  const setActiveLink = (id) => {
    navLinks.forEach((link) => {
      link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
    });
  };

  if ('IntersectionObserver' in window) {
    const sectionObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActiveLink(entry.target.id);
        });
      },
      // Região central da viewport: a seção mais visível vence
      { rootMargin: '-40% 0px -55% 0px', threshold: 0 }
    );

    sections.forEach((section) => sectionObserver.observe(section));
  }
})();